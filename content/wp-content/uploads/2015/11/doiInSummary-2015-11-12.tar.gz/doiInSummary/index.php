<?php

/**
 * Copyright (c) 20015 Lepidus Tecnologia
 * Distributed under the GNU GPL v2. For full terms see the file docs/COPYING.
 */

require_once('DoiInSummaryPlugin.inc.php');

return new DoiInSummaryPlugin();

?>
