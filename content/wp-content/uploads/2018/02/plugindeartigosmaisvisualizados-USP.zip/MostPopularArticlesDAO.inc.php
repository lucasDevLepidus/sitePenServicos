<?php

/**
 * @file MostPopularArticlesDAO.inc.php
 *
 * Copyright (c) 2000-2008 John Willinsky
 * Distributed under the GNU GPL v2. For full terms see the file docs/COPYING.
 *
 * @class MostPopularArticlesDAO
 * @ingroup plugins_blocks_popularArticles
 *
 * @brief Class for Popular Article Block plugin
 */

import('lib.pkp.classes.db.DAO');

class MostPopularArticlesDAO extends DAO {

	/*
	 * Gets the $num most popular articles in the last $months months.
	 * If $months = null it shows articles of all time
	 */
	function getMostPopularArticles($journalId, $num = 10, $months = null) {
		$publishedArticleDao = DAORegistry::getDAO('PublishedArticleDAO');

		import('lib.pkp.classes.db.DBResultRange');
		$journalDao =& DAORegistry::getDAO('JournalDAO'); /* @var $journalDao JournalDAO */
		$journal =& $journalDao->getJournal($journalId);

		$metricsDao =& DAORegistry::getDAO('MetricsDAO'); /* @var $metricsDao MetricsDAO */

		// Get old view statistics.
		PluginRegistry::loadCategory('reports');
		$stats = $metricsDao->getMetrics(
			array('ojs::counter'),
			array(STATISTICS_DIMENSION_SUBMISSION_ID),
			array(STATISTICS_DIMENSION_CONTEXT_ID => $journalId, STATISTICS_DIMENSION_ASSOC_TYPE => 260, 'file_type' => 2),
			array(STATISTICS_METRIC => STATISTICS_ORDER_DESC),
			null,
			false
		);

		$articlesInfo = array();
		foreach ($stats as $statRecord) {
			if (count($articlesInfo) == $num) break;

			$articleId = $statRecord[STATISTICS_DIMENSION_SUBMISSION_ID];
			$count = $statRecord[STATISTICS_METRIC];

			$article = $publishedArticleDao->getPublishedArticleByArticleId($articleId); /* @var $article PublishedArticle */

			if (!is_a($article, 'PublishedArticle')) continue;

			if (!is_null($months)) {
				$limit = strtotime('-' . $months . ' months');
				if (strtotime($article->getDatePublished()) < $limit) continue;
			}

			$articlesInfo[$articleId] = array(
				'article' => $article,
				'views' => $count
			);
		}

		return $articlesInfo;
	}

}

?>
